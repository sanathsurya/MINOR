# This file is required to treat the 'routes' folder as a Python package.

from .auth_routes import auth_bp
from .file_routes import file_bp
